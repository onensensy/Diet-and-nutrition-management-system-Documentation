<center>
# TO-DO
</center>
<hr>
<p> 
This todo follows chapter by chapter Approach and its purpose is to help in the Systematic and Error free writing of the document
</p>
<p>Please follow the syntax of creating a task to be done. </p>
<p>Incase of any changes to be added, Please include it i this document so that the TexCoders can work on it. Or you can also create an issue in the repo.</p>


#### General Format
1. Chapter 1
    - [x] Task 1  -- <i>This indicates a completed task</i>
2. Chapter 2
    - [x] <strike> Task 1 </strike> -- <i>This indicates a task that was planned, implemented but then later removed</i>
    - [ ] Task 2 -- <i>This indicates an incomplete task that is supposed to bbe performed</i>
3. Research Methodology
    - [ ] Task 1


<hr>
<h1>Document Start</h1>
<hr>
### General

- [ ] <strike>Margin for the 1st and second Page=1in, Other pages normal</strike>
- [x] Add List of tables for the Appendix
- [x] Fix Table borders
- [x] <strike>Add labels to all tables </strike>
- [x] Remove any form of website
- [x] References (Remove the URL: text)
- [x] Explain the PHP bits
- [x] font size

<hr>
### Chapter by Chapter

1. Introduction
    - [x] Higlighted under specfic objectives   
    - [x] Citation missed
2. Literature Review
    - [x] Add footnote on the table of comparison stating that the blank cells indicate that the feature is not present  //(Additionally Added some text).
3. Research Methodology
    - [x] Fix/Insert table in Methodology
    - [x] Add caption to the image Changes
    - [x] Spelling Mistakes check
4. Appendix
    - [x] Appendix A table formating
<hr>
